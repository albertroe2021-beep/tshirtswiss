# TShirtSwiss SVG Icon Mapping - Uniform Weight

All SVG previews and normalized SVG files use `#e1111a` and stroke width `2.6`, matching the Ref#1 preview weight.

| Ref# | Category | Website Term | Suggested SVG Concept | SVG File | Reuse Count |
|---:|---|---|---|---|---:|
| 1 | Brand & Trust | Swiss Managed | Swiss shield with cross | shield-with-cross-svgrepo-com (1).svg | 2 |
| 2 | Brand & Trust | Factory in Thailand | Factory building with chimney | factory-building-svgrepo-com.svg | 2 |
| 3 | Brand & Trust | Premium Quality | Award ribbon with check | quality-5-svgrepo-com.svg | 4 |
| 4 | Brand & Trust | Quality Control | Clipboard with check | quality-5-svgrepo-com.svg | 4 |
| 5 | Brand & Trust | Quality Assurance | Shield with check | quality-5-svgrepo-com.svg | 4 |
| 6 | Brand & Trust | Worldwide Shipping | Shipping box — same as #27 Packaging | plane-svgrepo-com (1).svg | 2 |
| 7 | Brand & Trust | Fast Turnaround | Fast stopwatch with motion lines | stopwatch-svgrepo-com.svg | 1 |
| 8 | Brand & Trust | Long-Term Partner | Handshake | handshake-svgrepo-com.svg | 1 |
| 9 | Brand & Trust | Dedicated Account Manager | Call centre headset person | person-with-headset-thin-outline-symbol-in-a-circle-svgrepo-com (1).svg | 4 |
| 10 | Brand & Trust | Consultation | Speech bubbles | speech-bubbles-conversation-svgrepo-com (1).svg | 1 |
| 11 | Manufacturing Process | Product Development | Computer monitor | computer-monitor-svgrepo-com.svg | 4 |
| 12 | Manufacturing Process | Design Review | Magnifier over T-shirt | review-checkmark-svgrepo-com.svg | 2 |
| 13 | Manufacturing Process | Pattern Making | Pattern making sheet with drafting marks and ruler | design-svgrepo-com.svg | 2 |
| 14 | Manufacturing Process | CAD Design | Computer monitor | computer-monitor-svgrepo-com.svg | 4 |
| 15 | Manufacturing Process | Tech Pack | Clipboard with garment drawing | sketch-svgrepo-com.svg | 1 |
| 16 | Manufacturing Process | Sampling | T-shirt | review-checkmark-svgrepo-com.svg | 2 |
| 17 | Manufacturing Process | Sample Approval | T-shirt with approval tick | quality-5-svgrepo-com.svg | 4 |
| 18 | Manufacturing Process | Fabric Selection | Fabric roll with scissors | fabric-material-svgrepo-com.svg | 6 |
| 19 | Manufacturing Process | Trims Selection | Fabric roll with scissors | design-svgrepo-com.svg | 2 |
| 20 | Manufacturing Process | Production | Factory | factory-building-svgrepo-com.svg | 2 |
| 21 | Manufacturing Process | Sewing | Sewing machine | sewing-machine-sew-svgrepo-com (1).svg | 1 |
| 22 | Manufacturing Process | Cutting | Pair of scissors | scissors-svgrepo-com.svg | 1 |
| 23 | Manufacturing Process | Embroidery | Embroidery hoop and needle | needle-svgrepo-com.svg | 2 |
| 24 | Manufacturing Process | Screen Printing | Screen frame and squeegee | paint-roller-svgrepo-com.svg | 1 |
| 25 | Manufacturing Process | Heat Transfer | Heat press | airport-baggage-conveyor-svgrepo-com.svg | 2 |
| 26 | Manufacturing Process | Sublimation | Heat press with droplets | airport-baggage-conveyor-svgrepo-com.svg | 2 |
| 27 | Manufacturing Process | Packaging | Shipping box | box-svgrepo-com.svg | 2 |
| 28 | Manufacturing Process | Dispatch | Shipping box — same as #27 Packaging | plane-svgrepo-com (1).svg | 2 |
| 29 | Products | T-Shirts | T-shirt | tshirt-svgrepo-com (2).svg | 1 |
| 30 | Products | Polos | Polo shirt | cotton-polo-shirt-svgrepo-com.svg | 1 |
| 31 | Products | Hoodies | Hoodie | sweatshirt-svgrepo-com.svg | 1 |
| 32 | Products | Workwear | Hi-vis vest | construction-worker-svgrepo-com.svg | 2 |
| 33 | Products | Corporate Apparel | Shirt and tie | shirt-svgrepo-com.svg | 2 |
| 34 | Products | Sportswear | Running shirt | team-uniform-svgrepo-com.svg | 3 |
| 35 | Products | Rashguards | Compression shirt | paralympic-swimming-silhouette-svgrepo-com.svg | 1 |
| 36 | Products | MMA Shorts | Fight shorts | boxing-shorts-svgrepo-com.svg | 3 |
| 37 | Products | Muay Thai Shorts | Muay Thai shorts | boxing-shorts-svgrepo-com.svg | 3 |
| 38 | Products | Medical Scrubs | Scrub top | doctor-female-svgrepo-com.svg | 3 |
| 39 | Products | Healthcare Uniforms | Medical tunic | doctor-female-svgrepo-com.svg | 3 |
| 40 | Products | Caps & Headwear | Cap | cap-svgrepo-com.svg | 1 |
| 41 | Products | Jackets | Jacket | jacket-svgrepo-com.svg | 1 |
| 42 | Products | Tote Bags | Tote bag | shopping-bag-svgrepo-com.svg | 3 |
| 43 | Products | Promotional Merchandise | Gift box | team-uniform-svgrepo-com.svg | 3 |
| 44 | Branding Services | Private Label | Clothing label | barcode-sticker-svgrepo-com.svg | 5 |
| 45 | Branding Services | Custom Labels | Sew-in label | barcode-sticker-svgrepo-com.svg | 5 |
| 46 | Branding Services | Hang Tags | Swing tag | tag-2-svgrepo-com.svg | 1 |
| 47 | Branding Services | Woven Labels | Woven label | barcode-sticker-svgrepo-com.svg | 5 |
| 48 | Branding Services | Neck Labels | Collar label | barcode-sticker-svgrepo-com.svg | 5 |
| 49 | Branding Services | Custom Packaging | Branded box | box-svgrepo-com.svg | 2 |
| 50 | Branding Services | Fold & Bag | Folded shirt in polybag | shopping-bag-svgrepo-com.svg | 3 |
| 51 | Branding Services | Barcode Labelling | Barcode tag | barcode-sticker-svgrepo-com.svg | 5 |
| 52 | Printing & Decoration | DTG Printing | Printer with T-shirt | print-products-svgrepo-com (1).svg | 4 |
| 53 | Printing & Decoration | Puff Print | Raised print layer | print-products-svgrepo-com (1).svg | 4 |
| 54 | Printing & Decoration | Silicone Print | Silicone droplet | print-products-svgrepo-com (1).svg | 4 |
| 55 | Printing & Decoration | Reflective Print | Reflective star | print-products-svgrepo-com (1).svg | 4 |
| 56 | Printing & Decoration | Puff Embroidery | Fabric roll with scissors | needle-svgrepo-com.svg | 2 |
| 57 | Fabrics | Cotton | Fabric roll with scissors | fabric-material-svgrepo-com.svg | 6 |
| 58 | Fabrics | Organic Cotton | Fabric roll with scissors | fabric-material-svgrepo-com.svg | 6 |
| 59 | Fabrics | Polyester | Fabric roll with scissors | fabric-material-svgrepo-com.svg | 6 |
| 60 | Fabrics | Bamboo | Fabric roll with scissors | bamboo-svgrepo-com.svg | 2 |
| 61 | Fabrics | Recycled Fabric | Fabric roll with scissors | fabric-material-svgrepo-com.svg | 6 |
| 62 | Fabrics | Moisture Wicking | Fabric roll with scissors | keep-dry-svgrepo-com.svg | 1 |
| 63 | Fabrics | Stretch Fabric | Fabric roll with scissors | fabric-material-svgrepo-com.svg | 6 |
| 64 | Fabrics | Anti-Bacterial | Fabric roll with scissors | germs-svgrepo-com.svg | 1 |
| 65 | Fabrics | UPF Protection | Sun and fabric | sun-cream-sun-protection-svgrepo-com.svg | 1 |
| 66 | Industries | Construction | Hard hat | construction-worker-svgrepo-com.svg | 2 |
| 67 | Industries | Healthcare | Medical cross | doctor-female-svgrepo-com.svg | 3 |
| 68 | Industries | Hospitality | Serving tray | hotel-reception-svgrepo-com.svg | 1 |
| 69 | Industries | Fitness | Dumbbell | team-uniform-svgrepo-com.svg | 3 |
| 70 | Industries | Combat Sports | Boxing glove | boxing-shorts-svgrepo-com.svg | 3 |
| 71 | Industries | Corporate | Office building | shirt-svgrepo-com.svg | 2 |
| 72 | Industries | Ecommerce Brands | Shopping bag | shopping-bag-svgrepo-com.svg | 3 |
| 73 | Industries | Influencer Brands | Megaphone | facebook-svgrepo-com.svg | 1 |
| 74 | Industries | Events & Merchandise | Event ticket | rock-and-roll-concert-svgrepo-com.svg | 1 |
| 75 | Sustainability | Sustainability | Leaf | bamboo-svgrepo-com.svg | 2 |
| 76 | Sustainability | Eco-Friendly | Leaf in circle | recycling-arrows-svgrepo-com.svg | 6 |
| 77 | Sustainability | Recycled Materials | Recycle arrows | recycling-arrows-svgrepo-com.svg | 6 |
| 78 | Sustainability | Ethical Manufacturing | Hands holding heart | recycling-arrows-svgrepo-com.svg | 6 |
| 79 | Sustainability | Carbon Reduction | Leaf and CO2 | recycling-arrows-svgrepo-com.svg | 6 |
| 80 | Sustainability | Waste Reduction | Recycling bin | recycling-arrows-svgrepo-com.svg | 6 |
| 81 | Sustainability | Water Saving | Water droplet | water-drop-svgrepo-com.svg | 1 |
| 82 | Sustainability | Renewable Energy | Solar panel | recycling-arrows-svgrepo-com.svg | 6 |
| 83 | Resources | Blog | Newspaper | computer-monitor-svgrepo-com.svg | 4 |
| 84 | Resources | FAQ | Question bubble | computer-monitor-svgrepo-com.svg | 4 |
| 85 | Resources | Downloads | Download arrow | downloads-svgrepo-com.svg | 1 |
| 86 | Resources | Case Studies | Open folder | book-svgrepo-com.svg | 3 |
| 87 | Resources | Guides | Open book | book-svgrepo-com.svg | 3 |
| 88 | Resources | Resources | Library/books | book-svgrepo-com.svg | 3 |
| 89 | Resources | Search | Magnifying glass | search-alt-2-svgrepo-com.svg | 1 |
| 90 | Contact | Contact | Envelope | person-with-headset-thin-outline-symbol-in-a-circle-svgrepo-com (1).svg | 4 |
| 91 | Contact | Phone | Telephone | person-with-headset-thin-outline-symbol-in-a-circle-svgrepo-com (1).svg | 4 |
| 92 | Contact | WhatsApp | WhatsApp bubble | whatsapp-svgrepo-com.svg | 1 |
| 93 | Contact | Email | Mail | email-svgrepo-com.svg | 2 |
| 94 | Contact | Switzerland Office | Swiss shield | shield-with-cross-svgrepo-com (1).svg | 2 |
| 95 | Contact | Request a Quote | Clipboard with quote/check | email-svgrepo-com.svg | 2 |
| 96 | Contact | Schedule a Call | Call centre headset person | person-with-headset-thin-outline-symbol-in-a-circle-svgrepo-com (1).svg | 4 |
